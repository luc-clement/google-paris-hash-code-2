package fr.google.paris.hashcode.qualificationRound;

public class PlacementException extends Exception {
	
	public PlacementException(String msg) {
		super(msg);
	}

}
