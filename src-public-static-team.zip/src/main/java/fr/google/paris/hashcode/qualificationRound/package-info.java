/**
 * @author PublicStaticTeam
 *
 * Package for Qualification Round
 */
package fr.google.paris.hashcode.qualificationRound;