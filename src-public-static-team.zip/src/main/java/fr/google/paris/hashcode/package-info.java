/**
 * @author PublicStaticTeam
 *
 * Main Package
 */
package fr.google.paris.hashcode;